@echo off
rem QuantMind portable update apply
rem Place this zip's content over the package root first, then run me.
rem I stop services, finish copying (idempotent), and tell you to restart.
setlocal
cd /d "%~dp0"
set "ROOT=%CD%"
echo [update] package root: %ROOT%
echo [update] stopping services...
taskkill /FI "WINDOWTITLE eq QuantMind-CeleryBeat*" /T /F >nul 2>&1
taskkill /FI "WINDOWTITLE eq QuantMind-CeleryWorker*" /T /F >nul 2>&1
taskkill /FI "WINDOWTITLE eq QuantMind-Backend*" /T /F >nul 2>&1
taskkill /FI "WINDOWTITLE eq QuantMind-Redis*" /T /F >nul 2>&1
taskkill /FI "WINDOWTITLE eq QuantMind-Huntly*" /T /F >nul 2>&1
taskkill /FI "WINDOWTITLE eq QuantMind-QwenPaw*" /T /F >nul 2>&1
taskkill /FI "IMAGENAME eq python.exe" /F >nul 2>&1
if exist "%ROOT%\pgdata\PG_VERSION" if exist "%ROOT%\pgsql\bin\pg_ctl.exe" (
    "%ROOT%\pgsql\bin\pg_ctl.exe" -D "%ROOT%\pgdata" stop -m fast >nul 2>&1
)
echo [update] files were merged by your unzip before this step.
echo [update] clearing __pycache__ to avoid stale bytecode...
for /d /r "%ROOT%\backend" %%d in (__pycache__) do rd /s /q "%%d" 2>nul
echo.
echo [update] Done. Start the package with start.bat now.
echo [update] If something fails, send logs\backend.log to the maintainer.
pause
endlocal
