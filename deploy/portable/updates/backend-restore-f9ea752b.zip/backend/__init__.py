"""QuantMind backend package."""
