"""
Portfolio middleware adapter.
"""
