#!/usr/bin/env python3
"""本地信号因子 IC/ICIR 检验器（不入库，仅本机使用）。

评估对象: 6_ml_datasets/{ccass_factors,south_factors} 的全部数值因子。
方法:
  - 日频截面 Spearman Rank IC 流：因子与未来收益同时取秩后逐日求相关
  - ICIR = IC 均值 / std(ddof=1)；ic_pos_rate 为日度 IC>0 的占比
  - 防前视铁律：t 日披露数据次日方可交易 → ret(t→t+h)=close[t+h]/close[t+1]-1
  - --neutral: 对 log(总市值) 秩做横截面正交化后的"残差 IC"
  - --mode events: 大行托管线 Δ5d 越阈值事件的前瞻超额收益表

用法:
  python backend/scripts/evaluate_signal_factors.py --selftest       # 快速自检
  python backend/scripts/evaluate_signal_factors.py --mode ic --neutral
  python backend/scripts/evaluate_signal_factors.py --mode events
"""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

import numpy as np
import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PROJECT_ROOT))

log = logging.getLogger("evaluate_signal_factors")
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

NON_FACTOR_COLS = {"symbol", "date"}
MIN_NAMES_PER_DAY = 100          # 单日截面最少标的数
MIN_OBS = 30                     # 最少有效 IC 观测数
OUT_DIR = Path(PROJECT_ROOT) / "logs"


def _hub():
    from backend.services.engine.data_platform.quanthk_hub import QuantHKDataHub

    return QuantHKDataHub()


def _close_matrix(hub, start: pd.Timestamp) -> pd.DataFrame:
    """收盘价宽表 trade_date × instrument。"""
    from backend.scripts.update_market_features import load_hk_parquet

    df = load_hk_parquet(start_year=int(start.year) - 2)
    df["trade_date"] = pd.to_datetime(df["trade_date"])
    df = df[df["trade_date"] >= start - pd.Timedelta(days=14)]
    return df.pivot_table(index="trade_date", columns="instrument",
                          values="close", aggfunc="last").sort_index()


def _size_panel(hub, start: pd.Timestamp) -> pd.DataFrame | None:
    """log(总市值) 控制面板（从 CCASS 反推发行股本 × 收盘价）。

    model_features_hk 的 total_mv 全为 0（港股市值未填充），改用：
      issued_shares ≈ holding_quantity / holding_percentage（每股日取中位数）
      cap = issued_shares × close
    """
    root = hub.data_dir / "2_base_sector" / "ccass_top50"
    if not root.is_dir():
        return None
    frames: list[pd.DataFrame] = []
    for f in sorted(root.glob("dt=*/data.parquet")):
        try:
            c = pd.read_parquet(f, columns=["stock_code", "holding_quantity",
                                            "holding_percentage", "query_date"])
        except Exception:  # noqa: BLE001
            continue
        c["_date"] = pd.to_datetime(c["query_date"], errors="coerce")
        c = c[(c["_date"] >= start) & (c.holding_percentage > 0)
              & (c.holding_quantity > 0)]
        if len(c):
            frames.append(c)
    if not frames:
        return None
    big = pd.concat(frames, ignore_index=True)
    big["issued"] = big.holding_quantity / big.holding_percentage
    issued = big.groupby(["stock_code", "_date"])["issued"].median().rename("issued")
    closes_sub = closes_global_for_size(big["_date"].min(), big["_date"].max())
    cap = issued.reset_index().merge(
        closes_sub.stack().rename("close").reset_index().rename(
            columns={"trade_date": "_date", "instrument": "stock_code"}),
        on=["stock_code", "_date"], how="left")
    cap["ln_mv"] = np.log(cap.issued * cap.close)
    w = cap.pivot_table(index="_date", columns="stock_code",
                        values="ln_mv", aggfunc="mean").sort_index()
    w.index.name = None
    return w


def closes_global_for_size(min_d, max_d) -> pd.DataFrame:
    """供市值面板使用的收盘价窗口（延迟导入避免循环依赖）。"""
    from backend.scripts.update_market_features import load_hk_parquet

    df = load_hk_parquet(start_year=int(pd.Timestamp(min_d).year) - 2)
    df["trade_date"] = pd.to_datetime(df["trade_date"])
    df = df[(df["trade_date"] >= pd.Timestamp(min_d) - pd.Timedelta(days=10))
            & (df["trade_date"] <= pd.Timestamp(max_d) + pd.Timedelta(days=10))]
    return df.pivot_table(index="trade_date", columns="instrument",
                          values="close", aggfunc="last").sort_index()


def _load_dataset_long(root: Path, start: pd.Timestamp) -> pd.DataFrame | None:
    """读全部 dt 分区为长表（date/symbol + 数值因子列）。"""
    frames: list[pd.DataFrame] = []
    for f in sorted(root.glob("dt=*/data.parquet")):
        try:
            s = pd.read_parquet(f)
            s["date"] = pd.to_datetime(s["date"], errors="coerce")
            s = s[s["date"] >= start]
            if len(s):
                frames.append(s)
        except Exception:  # noqa: BLE001
            continue
    if not frames:
        return None
    return pd.concat(frames, ignore_index=True)


def _align_grid(df: pd.DataFrame, index: pd.Index,
                cols: pd.Index) -> tuple[np.ndarray, np.ndarray]:
    m = df.reindex(index=index, columns=cols)
    r = m.rank(axis=1)
    return r.to_numpy(float), r.notna().to_numpy()


def _ic_stats(ranks_f: np.ndarray, ranks_fwd: np.ndarray,
              masks_f: np.ndarray | None, masks_fwd: np.ndarray | None) -> tuple[int, float, float, float]:
    n_days = min(ranks_f.shape[0], ranks_fwd.shape[0])
    ics: list[float] = []
    for i in range(n_days):
        if masks_f is not None and masks_fwd is not None:
            mask = masks_f[i] & masks_fwd[i]
        else:
            mask = ~(np.isnan(ranks_f[i]) | np.isnan(ranks_fwd[i]))
        if mask.sum() < MIN_NAMES_PER_DAY:
            continue
        fa = ranks_f[i][mask]
        fb = ranks_fwd[i][mask]
        sa, sb = fa.std(), fb.std()
        if sa == 0 or sb == 0:
            continue
        fa = fa - fa.mean()
        fb = fb - fb.mean()
        ics.append(float((fa * fb).sum() / (len(fa) * sa * sb)))
    if len(ics) < MIN_OBS:
        return len(ics), float("nan"), float("nan"), float("nan")
    arr = np.asarray(ics)
    std = arr.std(ddof=1)
    icir = arr.mean() / std if std > 0 else float("nan")
    return len(arr), float(arr.mean()), float(icir), float((arr > 0).mean())


def run_ic(datasets: list[str], hub, closes: pd.DataFrame, start: pd.Timestamp,
           horizons: list[int], neutral: bool) -> pd.DataFrame:
    # 网格矩阵一律 numpy 化，避免 pandas 标签对齐引发隐藏广播问题
    size_np = _size_panel(hub, start)
    size_grid = (
        size_np.reindex(index=closes.index, columns=closes.columns).to_numpy(float)
        if size_np is not None else None
    )
    if neutral and size_grid is None:
        log.warning("--neutral 因缺市值面板而退化")
    if neutral and size_grid is not None:
        log.info("规模中性化: 已启用 log(total_mv)")

    # 未来收益与秩（统一价格网格；T+1 防前视）
    fwd_rank_mat: dict[int, tuple[np.ndarray, np.ndarray]] = {}
    fwd_level_mask: dict[int, np.ndarray] = {}
    for h in horizons:
        fwd_ret = closes.shift(-h) / closes.shift(-1) - 1
        fwd_level_mask[h] = ~fwd_ret.isna().to_numpy()
        fwd_rank_mat[h] = _align_grid(fwd_ret, closes.index, closes.columns)

    result_rows: list[dict] = []
    for name in datasets:
        root = hub.data_dir / "6_ml_datasets" / name
        if not root.is_dir():
            log.warning("跳过不存在数据集 %s", name)
            continue

        panels: dict[str, list[pd.DataFrame]] = {}
        sample_count = 0
        for f in sorted(root.glob("dt=*/data.parquet")):
            try:
                s = pd.read_parquet(f)
            except Exception:  # noqa: BLE001
                continue
            s["date"] = pd.to_datetime(s["date"], errors="coerce")
            s = s[s["date"] >= start]
            if len(s) == 0:
                continue
            sample_count += 1
            num_cols = [c for c in s.columns
                        if c not in NON_FACTOR_COLS
                        and pd.api.types.is_numeric_dtype(s[c])]
            for c in num_cols:
                g = s[[c, "date", "symbol"]].dropna(subset=[c])
                panels.setdefault(c, []).append(g.rename(columns={c: "_v"}))
        if not panels or sample_count == 0:
            log.warning("空数据集: %s", name)
            continue
        log.info("[%s] 分区 %d 个；候选因子 %d 个", name, sample_count, len(panels))

        for fc, parts in sorted(panels.items()):
            panel = pd.concat(parts, ignore_index=True)
            w = panel.pivot_table(index="date", columns="symbol",
                                  values="_v", aggfunc="mean").sort_index()
            if w.shape[0] < MIN_OBS:
                continue

            variants: list[tuple[str, np.ndarray | None]] = [("raw", None)]
            if neutral and size_grid is not None:
                variants.append(("neut_size", size_grid))

            for variant_name, control_grid in variants:
                if control_grid is None:
                    r_mat, m_f = _align_grid(w, closes.index, closes.columns)
                else:
                    # 秩空间单变量正交：residual = rankF − slope·rankMV
                    f_arr, m_orig = _align_grid(w, closes.index, closes.columns)
                    mv_valid = ~np.isnan(control_grid)
                    both = m_orig & mv_valid
                    mean_f = np.nanmean(np.where(both, f_arr, np.nan), axis=1, keepdims=True)
                    mean_m = np.nanmean(np.where(both, control_grid, np.nan), axis=1, keepdims=True)
                    fc_dev = (f_arr - mean_f) * both
                    mv_dev = (control_grid - mean_m) * both
                    var_m = (mv_dev ** 2).sum(axis=1)
                    safe_var_m = np.where(var_m > 0, var_m, np.nan)
                    slope = np.divide((fc_dev * mv_dev).sum(axis=1), safe_var_m,
                                      out=np.full_like(safe_var_m, np.nan))
                    res_vals = fc_dev - np.nan_to_num(slope)[:, None] * mv_dev
                    res_vals[~m_orig] = np.nan      # 原始缺失保持缺失
                    r_mat, m_f = res_vals, ~(np.isnan(res_vals))

                for h in horizons:
                    ranks_fwd, masks_fwd = fwd_rank_mat[h]
                    n_obs, ic_mean, icir, ic_pos = _ic_stats(
                        r_mat, ranks_fwd, m_f, masks_fwd)
                    if n_obs < MIN_OBS or np.isnan(icir):
                        continue
                    result_rows.append({
                        "dataset": name, "factor": fc, "horizon": h,
                        "variant": variant_name, "n_obs": n_obs,
                        "rank_ic": round(float(ic_mean), 4),
                        "icir": round(float(icir), 3),
                        "abs_icir": abs(round(float(icir), 3)),
                        "ic_pos_rate": round(float(ic_pos), 3),
                    })

    df_out = pd.DataFrame(result_rows)
    if not df_out.empty:
        df_out = df_out.sort_values(["dataset", "abs_icir"], ascending=[True, False])
    return df_out


# ---------------------------------------------------------------- 事件研究


def run_events(hub, closes: pd.DataFrame, start: pd.Timestamp) -> pd.DataFrame:
    root = hub.data_dir / "6_ml_datasets" / "ccass_factors"
    if not root.is_dir():
        return pd.DataFrame()
    frames: list[pd.DataFrame] = []
    for f in sorted(root.glob("dt=*/data.parquet")):
        try:
            s = pd.read_parquet(f, columns=["symbol", "date", "ca_cust_pct_d5"])
            s["date"] = pd.to_datetime(s["date"], errors="coerce")
            s = s[s["date"] >= start]
            frames.append(s.dropna(subset=["date"]))
        except Exception:  # noqa: BLE001
            continue
    if not frames:
        return pd.DataFrame()
    panel = pd.concat(frames, ignore_index=True)

    fwd_by_h = {h: (closes.shift(-h) / closes.shift(-1) - 1) for h in (5, 10, 20)}
    out: list[dict] = []
    for thr_pct in (0.2, 0.5, 1.0):
        thr = thr_pct / 100
        for sign, label in ((1, "增仓"), (-1, "减仓")):
            ev = panel[sign * panel.ca_cust_pct_d5 >= thr]
            if ev.empty:
                continue
            n_events = len(ev)
            for h in (5, 10, 20):
                fw = fwd_by_h[h].clip(-0.3, 0.5).stack().rename("fwd").reset_index()
                fw.columns = ["date", "symbol", "fwd"]
                merged = ev.merge(fw, on=["date", "symbol"], how="left")
                # 全市场日度中位数作基准（含非事件股票），剔除共同漂移与子集偏置
                mkt_med = fw.groupby("date").fwd.median().rename("mkt_med")
                merged = merged.merge(mkt_med, on="date", how="left")
                merged["exc"] = merged.fwd - merged.mkt_med
                vals = merged.exc.dropna()
                out.append({
                    "direction": label, "thr_bp": int(thr_pct * 100), "horizon": h,
                    "n_events": n_events,
                    "n_measured": int(len(vals)),
                    "excess_avg_bp": round(float(vals.mean()) * 1e4, 1) if len(vals) else None,
                    "hit_rate": round(float((vals > 0).mean()), 3) if len(vals) else None,
                })
    df_out = pd.DataFrame(out).drop_duplicates(subset=["direction", "thr_bp", "horizon"])
    return df_out.sort_values(["direction", "thr_bp", "horizon"]) if not df_out.empty else df_out


# ---------------------------------------------------------------- 自检


def _selftest() -> int:
    """正向构造：把已知因子注入未来收益，检验器必须能把它识别出来。"""
    rng = np.random.default_rng(7)
    n_d, n_s = 260, 150
    syms = [f"S{i:03d}.HK" for i in range(n_s)]

    # 隐含真实 alpha 的慢变特征 c：次日收益 = 0.4% * tanh(c) + 噪声
    c = np.zeros((n_d, n_s))
    prev = rng.normal(size=n_s)
    for t in range(n_d):
        prev = 0.9 * prev + rng.normal(0, 0.3, n_s)
        c[t] = prev
    rets = np.zeros((n_d, n_s))
    rets[1:] = 0.004 * np.tanh(c[:-1]) + rng.normal(0, 0.01, size=(n_d - 1, n_s))
    price = pd.DataFrame(100 * np.cumprod(1 + rets, axis=0),
                         index=pd.bdate_range("2025-01-01", periods=n_d), columns=syms)

    def stats(factor_w: pd.DataFrame, horizon: int) -> float:
        rank_fwd = (price.shift(-horizon) / price.shift(-1) - 1).rank(axis=1)
        rf = factor_w.reindex(index=price.index, columns=syms).rank(axis=1)
        mask = rf.notna() & rank_fwd.notna()
        A = rf.to_numpy(float)
        B = rank_fwd.to_numpy(float)
        Mm = mask.to_numpy(bool)
        ics: list[float] = []
        for i in range(len(A)):
            fa = A[i][Mm[i]]
            fb = B[i][Mm[i]]
            sa, sb = fa.std(), fb.std()
            if sa == 0 or sb == 0 or len(fa) < 20:
                continue
            fa = fa - fa.mean()
            fb = fb - fb.mean()
            ics.append(float((fa * fb).sum() / (len(fa) * sa * sb)))
        arr = np.asarray(ics)
        return float(arr.mean() / arr.std(ddof=1))

    factor_known = pd.DataFrame(np.tanh(c), index=price.index, columns=syms)
    icir_alpha = stats(factor_known, horizon=10)
    print(f"[selftest] 注入信号的假因子 ICIR={icir_alpha:.2f}（应 >0.3）")
    assert icir_alpha > 0.3

    noise = pd.DataFrame(rng.normal(size=(n_d, n_s)), index=price.index, columns=syms)
    icir_noise = stats(noise, horizon=10)
    print(f"[selftest] 纯噪声 |ICIR|={abs(icir_noise):.3f}（应≈0）")
    assert abs(icir_noise) < 0.15
    print("[selftest] 通过")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="信号因子检验器")
    parser.add_argument("--selftest", action="store_true")
    parser.add_argument("--mode", choices=["ic", "events", "multi", "all"], default="all")
    parser.add_argument("--datasets", default="ccass_factors,south_factors")
    parser.add_argument("--start", default="2025-01-01")
    parser.add_argument("--horizons", default="1,3,5,10")
    parser.add_argument("--neutral", action="store_true")
    args, _ = parser.parse_known_args()

    if args.selftest:
        return _selftest()

    horizons = [int(x) for x in str(args.horizons).split(",")]
    start_ts = pd.Timestamp(args.start)
    hub = _hub()
    closes = _close_matrix(hub, start_ts)
    log.info("价格矩阵 %d 天 × %d 标的", *closes.shape)

    outputs: dict[str, pd.DataFrame] = {}
    if args.mode in ("ic", "all"):
        ic_df = run_ic([x.strip() for x in args.datasets.split(",")], hub,
                       closes, start_ts, horizons, args.neutral)
        if not ic_df.empty:
            outputs["ic"] = ic_df
    if args.mode in ("events", "all"):
        ev_df = run_events(hub, closes, start_ts)
        if not ev_df.empty:
            outputs["events"] = ev_df
    if args.mode in ("multi", "all"):
        return _main_multi(args, hub, closes, start_ts, horizons)

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    for key, frame in outputs.items():
        suffix = "_neutral" if key == "ic" and args.neutral else ""
        path = OUT_DIR / f"signal_report_{key}{suffix}.csv"
        frame.to_csv(path, index=False)
        print(f"\n===== {key.upper()}{' 中性化' if suffix else ''} ===== ({path})")
        show = frame[frame.abs_icir > 0.15] if key == "ic" else frame
        with pd.option_context("display.max_rows", 400, "display.width", 170):
            print(show.head(80).to_string(index=False))
    return 0


# ================================================================ 多因子模式

# 经 IC/中性化复检后确认的幸存因子（sign: +1 高值利好，-1 低值利好）
SURVIVORS = [
    ("ca_n_pis", "ccass_factors", -1),
    ("ca_hhi_disc", "ccass_factors", +1),
    ("ca_rank_overlap_20d", "ccass_factors", +1),
    ("ca_broker_pct", "ccass_factors", -1),
    ("ca_disclosed_sum", "ccass_factors", -1),
    ("ca_cust_share_disc", "ccass_factors", +1),
    ("ca_south_pct", "ccass_factors", -1),
    ("sb_quantity", "south_factors", +1),
]
MIN_FACTORS_FOR_COMPOSITE = 3


def _load_factor_wide(hub, dataset: str, factor: str,
                      start: pd.Timestamp, cols: pd.Index) -> pd.DataFrame | None:
    root = hub.data_dir / "6_ml_datasets" / dataset
    if not root.is_dir():
        return None
    frames: list[pd.DataFrame] = []
    for f in sorted(root.glob("dt=*/data.parquet")):
        try:
            s = pd.read_parquet(f, columns=["symbol", "date", factor])
        except Exception:  # noqa: BLE001
            continue
        s["date"] = pd.to_datetime(s["date"], errors="coerce")
        s = s[s["date"] >= start]
        if len(s):
            frames.append(s)
    if not frames:
        return None
    w = pd.concat(frames, ignore_index=True).pivot_table(
        index="date", columns="symbol", values=factor, aggfunc="mean").sort_index()
    return w.reindex(columns=cols)


def _rank_z(w: pd.DataFrame, sign: int) -> pd.DataFrame:
    """截面秩 z-score（纯 numpy 实现，避免 DataFrame-Series 标签对齐陷阱）。"""
    r = w.rank(axis=1).to_numpy(float)
    mask = ~np.isnan(r)
    arr = np.where(mask, r, np.nan)
    mean = np.nanmean(arr, axis=1, keepdims=True)
    std = np.nanstd(arr, axis=1, keepdims=True)
    z = np.divide(r - mean, std, out=np.full_like(r, np.nan),
                  where=(mask & (std > 0)))
    return pd.DataFrame(z * sign, index=w.index, columns=w.columns)


def run_multi(hub, closes: pd.DataFrame, start: pd.Timestamp,
              horizons: list[int]) -> dict[str, pd.DataFrame]:
    # 复用 IC 模式验证过的长表装载：每个数据集读一次，逐因子 pivot
    long_by_ds: dict[str, pd.DataFrame] = {}
    for ds in {d for _, d, _ in SURVIVORS}:
        root = hub.data_dir / "6_ml_datasets" / ds
        long_by_ds[ds] = _load_dataset_long(root, start) if root.is_dir() else None

    mats: dict[str, pd.DataFrame] = {}
    for factor, dataset, sign in SURVIVORS:
        long_df = long_by_ds.get(dataset)
        if long_df is None or factor not in long_df.columns:
            log.warning("跳过缺失因子 %s/%s", dataset, factor)
            continue
        w = long_df.pivot_table(index="date", columns="symbol",
                                values=factor, aggfunc="mean").sort_index()
        w = w.reindex(index=closes.index, columns=closes.columns)
        if w.shape[0] < MIN_OBS:
            log.warning("跳过短样本因子 %s", factor)
            continue
        mats[factor] = _rank_z(w, sign)
        log.info("mats[%s] shape=%s 达标日=%d",
                 factor, w.shape, int(w.notna().sum(axis=1).ge(MIN_NAMES_PER_DAY).sum()))

    # 1) 幸存因子两两平均截面秩相关（每 5 天抽样）
    names = list(mats)
    day_idx = sorted({d for m in mats.values() for d in m.index})[::5]
    corr_acc = {a: {b: [] for b in names} for a in names}
    for d in day_idx:
        rows = {}
        for a in names:
            if d in mats[a].index:
                rows[a] = mats[a].loc[d]
        for a in names:
            for b in names:
                if a == b or a not in rows or b not in rows:
                    continue
                va, vb = rows[a], rows[b]
                ok = va.notna() & vb.notna()
                if ok.sum() >= MIN_NAMES_PER_DAY:
                    ca, cb = va[ok].to_numpy(float), vb[ok].to_numpy(float)
                    if ca.std() and cb.std():
                        corr_acc[a][b].append(float(np.corrcoef(ca, cb)[0, 1]))
    corr_df = pd.DataFrame(
        {a: {b: (float(np.mean(corr_acc[a][b])) if corr_acc[a][b] else np.nan)
             for b in names} for a in names})

    # 2) 组合打分：方向一致的秩 z 均值（≥3 个因子可用时）
    comp = pd.concat(dict(mats), axis=1)
    comp_cnt = comp.notna().sum(axis=1)
    composite = comp.mean(axis=1, skipna=True).where(comp_cnt >= MIN_FACTORS_FOR_COMPOSITE)
    composite.name = "composite"
    mats["composite"] = composite.to_frame()

    # 3) 五分位多空收益（相对全市场日度中位数的超额，收益截尾防仙股极端值）
    def _fwd_matrix(h: int) -> pd.DataFrame:
        fwd = (closes.shift(-h) / closes.shift(-1) - 1).clip(-0.5, 1.0)
        return fwd.replace([np.inf, -np.inf], np.nan)

    mkt_med = {h: _fwd_matrix(h).median(axis=1) for h in horizons}
    rows: list[dict] = []
    for name, mat in mats.items():
        for h in horizons:
            if h < 2:            # h=1 在 T+1 口径下恒为 0，无信息
                continue
            fwd = _fwd_matrix(h)
            excess = fwd.sub(mkt_med[h], axis=0)
            ls_series = {}
            for d in mat.index:
                if d not in excess.index:
                    continue
                row_f = mat.loc[d]
                ok = row_f.notna()
                if ok.sum() < 5 * MIN_NAMES_PER_DAY // 5:
                    continue
                q = pd.qcut(row_f[ok].rank(method="first"), 5, labels=False)
                exc = excess.loc[d, ok]
                q5 = exc[q == 4].dropna()
                q1 = exc[q == 0].dropna()
                if len(q5) >= 20 and len(q1) >= 20:
                    ls_series[d] = float(q5.mean() - q1.mean())
            ls = pd.Series(ls_series).dropna()
            if len(ls) < MIN_OBS:
                continue
            arr = ls.to_numpy()
            mean_ls = float(arr.mean())
            std_ls = float(arr.std(ddof=1))
            t_stat = mean_ls / std_ls * np.sqrt(len(arr)) if std_ls > 0 else np.nan
            rows.append({
                "factor": name, "horizon": h, "n_days": len(arr),
                "ls_excess_bp": round(mean_ls * 1e4, 2),
                "ann_ls_pct": round(mean_ls * np.sqrt(252 / h) * 100, 2),
                "t_stat": round(float(t_stat), 2) if t_stat == t_stat else None,
                "hit_rate": round(float((arr > 0).mean()), 3),
            })
    portfolio = pd.DataFrame(rows)
    return {"corr": corr_df, "portfolio": portfolio}


def _main_multi(args, hub, closes, start_ts, horizons) -> int:
    out = run_multi(hub, closes, start_ts, horizons)
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    corr_csv = OUT_DIR / "signal_multi_corr.csv"
    pf_csv = OUT_DIR / "signal_multi_portfolio.csv"
    out["corr"].to_csv(corr_csv)
    out["portfolio"].to_csv(pf_csv, index=False)
    print(f"\n===== 因子相关性 (平均截面秩相关) ===== ({corr_csv})")
    with pd.option_context("display.width", 200):
        print(out["corr"].round(3).to_string())
    print(f"\n===== 五分位多空超额收益 ===== ({pf_csv})")
    with pd.option_context("display.width", 160):
        print(out["portfolio"].sort_values(["factor", "horizon"]).to_string(index=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())


