#!/usr/bin/env python3
"""本地信号因子数据集生成器（不入库，仅本机使用）。

生成与南向/CCASS 相关的训练直连 ML 数据集：
  6_ml_datasets/south_factors/dt=*  南向持股占比及其变化
  6_ml_datasets/ccass_factors/dt=*  CCASS 头部参与者集中度与大行托管线

调用入口:
  python backend/scripts/build_ml_signal_datasets.py --dataset south
  python backend/scripts/build_ml_signal_datasets.py --dataset ccass
  python backend/scripts/build_ml_signal_datasets.py --dataset all

quanthk_daily_sync 通过可选 import 调用 refresh_signal_datasets()，模块缺失时优雅跳过。
"""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

import numpy as np
import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PROJECT_ROOT))

log = logging.getLogger("build_ml_signal_datasets")
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

SOUTH_GAP_DAYS = 5


# ---------------------------------------------------------------- 公共工具


def _hub():
    from backend.services.engine.data_platform.quanthk_hub import QuantHKDataHub

    return QuantHKDataHub()


def _existing_partitions(root: Path, name: str) -> set[str]:
    d = root / name
    return {p.name[3:] for p in d.glob("dt=*")} if d.is_dir() else set()


def _atomic_partition_write(out_root: Path, name: str, dt_str: str,
                            frame: pd.DataFrame) -> bool:
    target_dir = out_root / name / f"dt={dt_str}"
    target_dir.mkdir(parents=True, exist_ok=True)
    tmp_path = target_dir / ".tmp-data.parquet"
    try:
        frame.to_parquet(tmp_path, index=False)
        tmp_path.replace(target_dir / "data.parquet")
        return True
    finally:
        tmp_path.unlink(missing_ok=True)


def _segment_flags(dates: pd.Series, max_gap_days: int) -> tuple[pd.Series, pd.Series]:
    """排序后把 >max_gap_days 的披露间断标记为分段边界；返回 (段号, 日历间隔)。"""
    gap_days = dates.diff().dt.days
    seg_id = (gap_days > max_gap_days).cumsum()
    return seg_id, gap_days.fillna(999)


# ================================================================ 南向因子


def _load_south_panel(hs_root: Path) -> pd.DataFrame:
    frames: list[pd.DataFrame] = []
    for f in sorted(hs_root.glob("dt=*/data.parquet")):
        try:
            s = pd.read_parquet(f, columns=["symbol", "query_date",
                                            "holding_percentage", "holding_quantity"])
        except Exception:  # noqa: BLE001
            continue
        frames.append(s)
    if not frames:
        return pd.DataFrame()
    panel = pd.concat(frames, ignore_index=True)
    panel["date"] = pd.to_datetime(panel["query_date"], errors="coerce")
    return panel.dropna(subset=["date", "symbol"]).drop_duplicates(["symbol", "date"], keep="last")


def _south_symbol_factors(g: pd.DataFrame) -> pd.DataFrame:
    """单只标的：披露间断 >5 自然日视为分段，跨段变化置空。"""
    g = g.sort_values("date").copy()
    seg_id, gap_days = _segment_flags(g["date"], SOUTH_GAP_DAYS)
    pct = g["holding_percentage"].astype(float)

    out = pd.DataFrame(index=g.index)
    out["sb_pct"] = pct
    out["sb_quantity"] = g["holding_quantity"].astype(float)
    d1 = pct.groupby(seg_id).diff()
    out["sb_pct_d1"] = d1.where(gap_days <= SOUTH_GAP_DAYS)
    out["sb_pct_d5"] = pct.groupby(seg_id).diff(5).where(gap_days <= SOUTH_GAP_DAYS)
    out["sb_pct_d20"] = pct.groupby(seg_id).diff(20).where(gap_days <= SOUTH_GAP_DAYS)

    def _z(values: pd.Series, win: int = 20, min_periods: int = 8) -> pd.Series:
        mean = values.groupby(seg_id).transform(
            lambda s: s.shift(1).rolling(win, min_periods=min_periods).mean())
        std = values.groupby(seg_id).transform(
            lambda s: s.shift(1).rolling(win, min_periods=min_periods).std())
        z = (values - mean) / std.replace(0, np.nan)
        return z.where(pd.Series(list(gap_days), index=values.index) <= SOUTH_GAP_DAYS)

    out["sb_pct_z20"] = _z(pct)
    up = d1 > 0
    streak = up.groupby([seg_id, (up != up.shift()).cumsum()]).cumsum()
    out["sb_consec_up"] = streak.where(gap_days <= SOUTH_GAP_DAYS).fillna(0).astype("int64")
    out["date"] = g["date"]
    out["symbol"] = g["symbol"]
    return out.reset_index(drop=True)


def build_south_factors() -> dict:
    """南向资金日频因子：持股占比水平/变化/滚动Z/连增。"""
    hub = _hub()
    hs_root = hub.data_dir / "2_base_sector" / "hsgt_south"
    out_root = hub.data_dir / "6_ml_datasets"
    out_root.mkdir(parents=True, exist_ok=True)
    existing = _existing_partitions(out_root, "south_factors")

    panel = _load_south_panel(hs_root)
    if panel.empty:
        return {"status": "no_data"}
    feats = pd.concat(
        [_south_symbol_factors(g) for _, g in panel.groupby("symbol")],
        ignore_index=True,
    )
    col_order = ["symbol", "date", "sb_quantity", "sb_pct",
                 "sb_pct_d1", "sb_pct_d5", "sb_pct_d20", "sb_pct_z20", "sb_consec_up"]

    written = 0
    for dt_key, g in feats.groupby(feats["date"].dt.date):
        dt_str = pd.Timestamp(dt_key).strftime("%Y%m%d")
        if dt_str in existing:
            continue
        out = g[col_order].sort_values("symbol").replace([np.inf, -np.inf], None)
        written += int(_atomic_partition_write(out_root, "south_factors", dt_str, out))
    return {"status": "ok", "partitions_written": written}


# ================================================================ CCASS 因子

# 托管行关键词（繁体为主，HKEX 页面原文）；命中即归为托管行（机构长线）
_CUSTODIAN_TOKENS = (
    "匯豐", "HSBC", "CITIBANK", "花旗", "JPMORGAN", "摩根大通", "CHASE",
    "STANDARD CHARTERED", "渣打", "STATE STREET", "道富", "DBS", "星展",
    "BANK OF CHINA", "中國銀行", "恒生銀行", "BNP", "法國巴黎", "NORTHERN TRUST",
    "BANK OF NEW YORK", "紐約梅隆", "BROWN BROTHERS", "COMMERZBANK",
    "UBS AG", "德意志銀行", "DEUTSCHE",
)
_SOUTH_IDS = ("A00003", "A00004")
_TOPK = (1, 3, 5, 10)


def _classify(name: str, pid: str) -> str:
    upper = name.upper()
    if pid in _SOUTH_IDS or "証券登記" in name or "证券登记" in name:
        return "csc"
    for tok in _CUSTODIAN_TOKENS:
        if tok.upper() in upper:
            return "cust"
    return "brok"


def _load_ccass_panel(root: Path) -> pd.DataFrame:
    """读全部日分区并做参与人分类 + 全股清洗。

    清洗规则：仅剔除"合计>105%"的分母异常日（公司行动未更新等）。
    合计低的细价股是真实的稀疏披露，保留（相对类因子用披露内份额）。"""
    cols = ["stock_code", "participant_id", "participant_name",
            "holding_percentage", "query_date"]
    frames: list[pd.DataFrame] = []
    for f in sorted(root.glob("dt=*/data.parquet")):
        try:
            s = pd.read_parquet(f, columns=cols)
        except Exception:  # noqa: BLE001
            continue
        s["_date"] = pd.to_datetime(s["query_date"], errors="coerce")
        frames.append(s)
    if not frames:
        return pd.DataFrame()
    p = pd.concat(frames, ignore_index=True).dropna(subset=["_date", "stock_code"])
    p["pctype"] = [_classify(str(n), str(i)) for n, i in zip(p.participant_name, p.participant_id, strict=True)]
    before = len(p)
    disc_sum = p.groupby(["stock_code", "_date"])["holding_percentage"].transform("sum")
    bad_high = disc_sum > 1.05
    p = p[~bad_high].reset_index(drop=True)
    log.info("CCASS 面板 %d 行；剔除超上限分母日 %.2f%%", len(p), 100 * len(p) / max(before, 1))
    return p


def _factor_daily_rows(day_groups, day_keys) -> list[dict]:
    """逐交易日聚合单只股票，输出含 Δ/进出/名次重叠 的日频行。"""
    rows: list[dict] = []
    ids_hist: list[frozenset[str]] = []

    for day, key_date in zip(day_groups, day_keys, strict=True):
        shares = day["holding_percentage"].to_numpy(dtype=float)
        pids = frozenset(day["participant_id"].astype(str))
        types = day["pctype"].to_numpy()
        disc_sum = float(shares.sum())

        size = int(len(day))
        cust_sum = float(shares[types == "cust"].sum())
        south_sum = float(shares[types == "csc"].sum())
        row: dict = {
            "_date": key_date,
            "date": key_date,
            "ca_disclosed_sum": round(disc_sum, 4),
            "ca_n_pis": size,
            "ca_south_pct": south_sum,
            "ca_cust_pct": cust_sum,
            "ca_broker_pct": float(shares[types == "brok"].sum()),
            "ca_cust_share_disc": cust_sum / disc_sum if disc_sum > 0 else None,
        }
        top_vals = np.sort(shares)[::-1]
        for k in _TOPK:
            row[f"ca_top{k}_pct"] = float(top_vals[:k].sum())
        if disc_sum > 0:
            w = shares / disc_sum
            row["ca_hhi_disc"] = float((w * w).sum())
        else:
            row["ca_hhi_disc"] = None

        for base, lag in (
            ("ca_cust_pct", 1), ("ca_cust_pct", 5), ("ca_cust_pct", 20),
            ("ca_top10_pct", 1), ("ca_top10_pct", 5),
            ("ca_south_pct", 1), ("ca_south_pct", 5), ("ca_south_pct", 20),
        ):
            col = f"{base}_d{lag}"
            if col not in row:
                row[col] = _delta_from(rows, row, base, lag)

        prev_ids = ids_hist[-1] if ids_hist else None
        base20 = ids_hist[-20] if len(ids_hist) >= 20 else None
        row["ca_new_entrants_1d"] = len(pids - prev_ids) if prev_ids else None
        row["ca_exits_1d"] = len(prev_ids - pids) if prev_ids else None
        if base20:
            union20 = pids | base20
            row["ca_rank_overlap_20d"] = len(pids & base20) / len(union20)
        else:
            row["ca_rank_overlap_20d"] = None
        rows.append(row)
        ids_hist.append(pids)
    return rows


def _delta_from(rows: list[dict], row: dict, base: str, lag: int) -> float | None:
    """相对 lag 个交易日前的同名字段差值；任一端缺失则置空。"""
    if len(rows) < lag or rows[-lag].get(base) is None or row.get(base) is None:
        return None
    return row[base] - rows[-lag][base]


def build_ccass_factors() -> dict:
    """CCASS 结构因子：集中度水平、大行托管线、券商线、南向双席位、
    边际行为、披露覆盖质量。面板适中，每次全量重算（确定性输出）。"""
    hub = _hub()
    cc_root = hub.data_dir / "2_base_sector" / "ccass_top50"
    out_root = hub.data_dir / "6_ml_datasets"
    out_root.mkdir(parents=True, exist_ok=True)

    panel = _load_ccass_panel(cc_root)
    if panel.empty:
        return {"status": "no_data"}

    feats_list: list[pd.DataFrame] = []
    for code, g in panel.groupby("stock_code"):
        rows = _factor_daily_rows([g_day for _, g_day in g.groupby("_date")],
                                  [key for key, _ in g.groupby("_date")])
        f = pd.DataFrame(rows)
        f["symbol"] = code
        feats_list.append(f)
    feats = pd.concat(feats_list, ignore_index=True)
    log.info("[hong_kong/ccass] 因子长表 %d 行 (%d 符号)", len(feats), feats.symbol.nunique())

    written = 0
    for dt_key, gg in feats.groupby(feats["_date"].dt.date):
        dt_str = pd.Timestamp(dt_key).strftime("%Y%m%d")
        written += int(_atomic_partition_write(
            out_root, "ccass_factors", dt_str,
            gg.drop(columns=["_date"]).sort_values("symbol").replace([np.inf, -np.inf], None)))
    return {"status": "ok", "partitions_written": written,
            "stocks": int(feats.symbol.nunique())}


# ================================================================ 入口

SIGNAL_DATASET_SPECS = [
    {"dataset": "south_factors", "name": "南向因子(日频)", "category_id": "6",
     "group": "ml", "rel_dir": "6_ml_datasets/south_factors", "layout": "partition",
     "note": "南向持股占比及其变化/连增/滚动Z，训练直连读取"},
    {"dataset": "ccass_factors", "name": "CCASS集中度因子(日频)", "category_id": "6",
     "group": "ml", "rel_dir": "6_ml_datasets/ccass_factors", "layout": "partition",
     "note": "头部集中度/大行托管线/边际行为，训练直连读取"},
]


def refresh_signal_datasets(result: dict) -> dict:
    """quanthk_daily_sync 收尾调用：增量刷新全部本地信号数据集。"""
    sub = {"south": build_south_factors(), "ccass": build_ccass_factors()}
    result.update({f"signal_{k}": v for k, v in sub.items()})
    return {k: v.get("status") for k, v in sub.items()}


def main() -> int:
    parser = argparse.ArgumentParser(description="本地信号因子数据集生成（南向/CCASS）")
    parser.add_argument("--dataset", choices=["south", "ccass", "all"], default="all")
    args, _ = parser.parse_known_args()
    if args.dataset in ("south", "all"):
        print(build_south_factors())
    if args.dataset in ("ccass", "all"):
        print(build_ccass_factors())
    return 0


if __name__ == "__main__":
    sys.exit(main())


# ================================================================ 快照合入


_SNAPSHOT_FILE = "model_features_hk.parquet"
_SIGNAL_COLS_CCASS = ("ca_n_pis", "ca_hhi_disc", "ca_rank_overlap_20d",
                      "ca_broker_pct", "ca_disclosed_sum", "ca_cust_share_disc",
                      "ca_south_pct")
_SIGNAL_COLS_SOUTH = ("sb_quantity", "sb_pct", "sb_pct_d5", "sb_pct_d20", "sb_pct_z20")


def merge_signal_into_snapshot() -> dict:
    """把南向/CCASS 因子按 (trade_date, instrument) 左连接合入 model_features_hk.parquet。

    非 A 股训练走单体快照（remote orchestrator 约定），合并后新因子即刻可被
    训练/推理管线读取。原文件先备份到 .backup/，防误操作。
    """
    import shutil

    import duckdb

    snap = Path(PROJECT_ROOT) / "db" / "feature_snapshots" / _SNAPSHOT_FILE
    if not snap.is_file():
        return {"status": "no_snapshot"}
    hub = _hub()
    cc_root = hub.data_dir / "6_ml_datasets" / "ccass_factors"
    sb_root = hub.data_dir / "6_ml_datasets" / "south_factors"

    bdir = snap.parent / ".backup"
    bdir.mkdir(exist_ok=True)
    bak = bdir / f"{_SNAPSHOT_FILE}.signal_bak"
    if not bak.is_file():
        shutil.copy2(snap, bak)

    import pyarrow.parquet as pq

    def _schema_cols(root: Path) -> set[str]:
        """全部分区 schema 的交集（跨代分区列名不一致时取公共列）。"""
        fs = sorted(root.glob("dt=*/data.parquet"))
        if not fs:
            return set()
        common = set(pq.ParquetFile(str(fs[0])).schema_arrow.names)
        for f in fs[1:]:
            common &= set(pq.ParquetFile(str(f)).schema_arrow.names)
        return common

    cc_avail = [c for c in _SIGNAL_COLS_CCASS if c in _schema_cols(cc_root)]
    sb_avail = [c for c in _SIGNAL_COLS_SOUTH if c in _schema_cols(sb_root)]
    cc_cols = ", ".join(f"c.{c}" for c in cc_avail)
    sb_cols = ", ".join(f"sb.{c}" for c in sb_avail)
    out_tmp = snap.parent / f".tmp_{_SNAPSHOT_FILE}"
    sql = f"""
    COPY (
      SELECT s.*, {cc_cols}, {sb_cols}
      FROM read_parquet('{snap}') AS s
      LEFT JOIN (
        SELECT CAST(date AS DATE) AS d, symbol, {', '.join(cc_avail)}
        FROM read_parquet('{cc_root}/dt=*/data.parquet')
      ) AS c
        ON c.d = s.trade_date AND c.symbol = s.instrument
      LEFT JOIN (
        SELECT CAST(date AS DATE) AS d, symbol, {', '.join(sb_avail)}
        FROM read_parquet('{sb_root}/dt=*/data.parquet')
      ) AS sb
        ON sb.d = s.trade_date AND sb.symbol = s.instrument
    ) TO '{out_tmp}' (FORMAT PARQUET)
    """
    con = duckdb.connect()
    con.execute(sql)
    con.close()
    out_tmp.replace(snap)
    schema = pq.ParquetFile(str(snap)).schema_arrow.names
    return {"status": "ok", "new_cols": [c for c in (*_SIGNAL_COLS_CCASS, *_SIGNAL_COLS_SOUTH)
                                         if c in schema],
            "backup": str(bak)}


def cli_signal():
    import argparse

    parser = argparse.ArgumentParser(description="本地信号因子/快照工具")
    sub = parser.add_subparsers(dest="cmd", required=True)
    sub.add_parser("snapshot-merge")
    args = parser.parse_args()
    if args.cmd == "snapshot-merge":
        print(merge_signal_into_snapshot())


if __name__ == "__main__":
    import sys
    sys.exit(cli_signal())
