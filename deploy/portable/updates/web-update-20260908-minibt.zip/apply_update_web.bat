@echo off
rem QuantMind frontend-only update helper.
rem Replace the packaged web/ contents with the new build shipped in newweb/.
cd /d "%~dp0"
if not exist "web" (
  echo [!] 'web' directory not found. Extract this zip to the portable package root first.
  pause
  exit /b 1
)
if not exist "newweb\index.html" (
  echo [!] 'newweb\index.html' not found. Package is incomplete.
  pause
  exit /b 1
)
echo [update] Removing old web\assets ...
if exist "web\assets" rd /s /q "web\assets"
echo [update] Copying new frontend into web\ ...
xcopy /e /y /q "newweb\." "web\" >nul
echo [update] Cleaning updater payload ...
rd /s /q "newweb"
echo [update] Done. Refresh the browser page or restart with start.bat.
pause
